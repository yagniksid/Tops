import React from 'react'

export default function Whishlist() {
    return (
        <div>Whishlist</div>
    )
}
