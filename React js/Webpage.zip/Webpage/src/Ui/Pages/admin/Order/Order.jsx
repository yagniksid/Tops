import React from 'react'

export default function Order() {
    return (
        <div>Order</div>
    )
}
