import { useState } from 'react'
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import HomePage from './UI/Pages/HomePage/HomePage';

export default function App() {
  return (
    <>
      <HomePage />
    </>
  )
}
