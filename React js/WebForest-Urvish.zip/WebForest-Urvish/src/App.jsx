import react from 'react'

import './App.css'
import Header from './UI/Component/Header/Header'

function App() {

  return (
    <>
      <Header />
    </>
  )
}

export default App
