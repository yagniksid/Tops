import React, { useState } from 'react';
import { Box, CircleUser, Mic, PackageCheck, Search, ShoppingCart, User } from "lucide-react";
import { Form, Input, InputGroup, InputGroupText } from 'reactstrap';
import logoImage from "../../../assets/images/images.png";
import LoginModal from '../Modal/LoginModal';

export default function Header() {
    const [modal, setModal] = useState(false);

    const toggle = () => setModal(!modal);
    return (
        <>
            <div style={{ boxShadow: "#00000047 1px 1px 3px 0px", }} className='pl-20 pe-3 flex items-center justify-between w-100 pt-3 pb-3 font-sans sticky-top top-0 bg-white'>
                <div className='pe-5'>
                    <img role='button' src={logoImage} className='h-16 w-16 ' alt="" />
                </div>
                <div className='' style={{ width: "57%" }}>
                    <Form>
                        <InputGroup>
                            <InputGroupText className=' bg-white'>
                                <Search strokeWidth={1} size={20} role='button' />
                            </InputGroupText>
                            <Input
                                type='search'
                                name='SearchBar'
                                placeholder='Search'
                                className='rounded-0 shadow-none !border-gray-200'
                                style={{ borderLeft: "none", borderRight: "none" }}
                            />
                            <InputGroupText className=' bg-white'>
                                <Mic strokeWidth={1} size={20} role='button' />
                            </InputGroupText>
                        </InputGroup>
                    </Form>
                </div>

                <div className='flex gap-10 items-center justify-center'>
                    <div className='flex flex-col justify-center gap-1 items-center mt-1'>
                        <User onClick={toggle} role='button' strokeWidth={1} />
                        <span role='button' onClick={toggle} className="tracking-widest text-[13px] text-decoration-none text-sm text-black" >Account</span>
                    </div>
                </div>
            </div>
            <LoginModal modal={modal} toggle={toggle} />
        </>
    );
}
