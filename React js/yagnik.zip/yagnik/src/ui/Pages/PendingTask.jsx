import React, { useState } from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button, Input, Table } from "reactstrap";
import { Trash } from "lucide-react";
import { completeTodo, deleteTodo } from "../../Redux/Features/todo";

export default function PendingTask() {
  let [pendingData, setPendingData] = useState();
  let [updateMode, setUpdateMode] = useState(false);
  let [index, setIndex] = useState(null);
  let dispatch = useDispatch();

  let data = useSelector((store) => {
    return store.todoSlice;
  });
  useEffect(() => {
    setPendingData(data.todo);
  }, [data]);

  let deleteHandler = (ele, index) => {
    dispatch(deleteTodo({ ele, index }));
  };

  return (
    <div className="d-flex justify-content-center">
      <div className="w-75">
        <Table>
          <thead>
            <tr>
              <th>Sr no.</th>
              <th>Todo</th>
              <th>Status</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {pendingData?.map((e, i) => {
              return (
                <tr key={i}>
                  <th scope="row">{i + 1}</th>
                  <td>{e.task}</td>
                  <td>
                    {e.isCompleted ? (
                      <span
                        role="button"
                        style={{ textDecoration: "underline", color: "green" }}
                        onClick={() =>
                          dispatch(completeTodo({ index: i, status: false }))
                        }
                      >
                        Complete
                      </span>
                    ) : (
                      <span
                        role="button"
                        style={{ textDecoration: "underline", color: "red" }}
                        onClick={() =>
                          dispatch(completeTodo({ index: i, status: true }))
                        }
                      >
                        {" "}
                        Pending{" "}
                      </span>
                    )}
                  </td>
                  <td>
                    <Trash
                      onClick={() => {
                        deleteHandler(e, i);
                      }}
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </div>
    </div>
  );
}
