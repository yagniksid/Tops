import { Button, Input } from "reactstrap";
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addTodo } from "../../Redux/Features/todo";
import PendingTask from "./PendingTask";

export default function HomePage() {
  let [todo, setTodo] = useState("");
  let dispatch = useDispatch();

  let submitHandler = () => {
    dispatch(addTodo(todo));
    setTodo("");
  };

  return (
    <>
      <div className="d-flex justify-content-center p-5">
        <div className="d-flex w-50 gap-3">
          <Input
            id="todo"
            name="todod"
            placeholder="Add todo here"
            type="text"
            value={todo}
            onChange={(e) => {
              setTodo(e?.target?.value);
            }}
          />
          <Button onClick={submitHandler}>Add</Button>
        </div>
      </div>
      <PendingTask />
    </>
  );
}
